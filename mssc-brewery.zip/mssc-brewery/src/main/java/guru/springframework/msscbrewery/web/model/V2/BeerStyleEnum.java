package guru.springframework.msscbrewery.web.model.V2;

public enum BeerStyleEnum {
	TUBORG, KINGFISHER, ALE, PIT;
}
