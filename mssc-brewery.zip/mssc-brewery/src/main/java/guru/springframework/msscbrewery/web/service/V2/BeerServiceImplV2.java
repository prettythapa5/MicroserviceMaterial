package guru.springframework.msscbrewery.web.service.V2;

import java.util.UUID;

import org.springframework.stereotype.Service;

import guru.springframework.msscbrewery.web.model.BeerDto;
import guru.springframework.msscbrewery.web.model.V2.BeerDtoV2;
import lombok.extern.log4j.Log4j2;

@Service
@Log4j2
public class BeerServiceImplV2 implements BeerServiceV2{

	@Override
	public BeerDtoV2 getBeerById(UUID beerId) {
		return BeerDtoV2.builder().id(UUID.randomUUID())
				.beerName("Tuborg")
				.beerStyle("Strong")
				.upc(100000L)
				.build();
	}

	@Override
	public BeerDtoV2 saveNewBeer(BeerDtoV2 beerDto) {
		return BeerDtoV2.builder()
				.id(UUID.randomUUID())
				.beerName("KingFisher")
				.build();
	}

	@Override
	public void updateBeer(UUID beerId, BeerDtoV2 beerDto) {
		// TODO impl- would add a real impl to beer Service
		
		
	}
	
	@Override
	public void deleteById(UUID beerId) {
		log.debug("Beer deleted-------------");		
	}

}
