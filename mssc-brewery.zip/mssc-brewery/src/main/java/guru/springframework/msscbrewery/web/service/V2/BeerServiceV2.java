package guru.springframework.msscbrewery.web.service.V2;

import java.util.UUID;

import guru.springframework.msscbrewery.web.model.V2.BeerDtoV2;

public interface BeerServiceV2 {

	Object getBeerById(UUID beerId);

	BeerDtoV2 saveNewBeer(BeerDtoV2 beerDtoV2);

	void updateBeer(UUID beerId, BeerDtoV2 beerDtoV2);

	void deleteById(UUID beerId);

}
