package guru.springframework.msscbrewery.web.service;

import java.util.UUID;

import org.springframework.stereotype.Service;

import guru.springframework.msscbrewery.web.model.BeerDto;
import lombok.extern.log4j.Log4j2;

@Log4j2
@Service
public class BeerServiceImpl implements BeerService{

	@Override
	public BeerDto getBeerById(UUID beerId) {
		return BeerDto.builder().id(UUID.randomUUID())
				.beerName("Tuborg")
				.beerStyle("Strong")
				.upc(100000L)
				.build();
	}

	@Override
	public BeerDto saveNewBeer(BeerDto beerDto) {
		return BeerDto.builder()
				.id(UUID.randomUUID())
				.beerName("KingFisher")
				.build();
	}

	@Override
	public void updateBeer(UUID beerId, BeerDto beerDto) {
		// TODO impl- would add a real impl to beer Service
		
		
	}
	
	@Override
	public void deleteById(UUID beerId) {
		log.debug("Beer deleted-------------");		
	}

}
