package guru.springframework.msscbrewery.web.model.V2;

import java.util.UUID;

import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;


@Data // creates getters & setters, equals and hashCodes at compile time
@NoArgsConstructor
@AllArgsConstructor
@Builder //builder pattern for lombok at compile time
public class BeerDtoV2 {
		private UUID id;
		private String beerName;
		private BeerStyleEnum beerStyle;
		private Long upc;

}
