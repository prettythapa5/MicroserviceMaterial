package guru.springframework.msscbrewery.web.controller;

import java.util.UUID;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpHeaders;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.ResponseStatus;

import guru.springframework.msscbrewery.web.model.CustomerDto;
import guru.springframework.msscbrewery.web.service.CustomerService;

@RequestMapping("api/v1/customer")
@Controller
public class CustomerController {
	@Autowired
	public CustomerService customerService;
	/*
	 * public CustomerController(CustomerService customerService) {
	 * this.customerService = customerService; }
	 */
	
	@GetMapping("/{customerId}")
	public ResponseEntity<CustomerDto> getCustomer(@PathVariable UUID customerId){
		return new ResponseEntity<>(customerService.getCustomerById(customerId), HttpStatus.OK);
	}

	@PostMapping	
	public ResponseEntity<CustomerDto> handlePost(CustomerDto customerDto){
		CustomerDto customer = customerService.saveNewCustomer(customerDto);
		HttpHeaders headers = new HttpHeaders();
        headers.add("Customer-Location", "/api/v1/customer/" + customer.getCustomerId().toString());
		
		//return new ResponseEntity<BeerDto>(headers, HttpStatus.ACCEPTED);
        
		return new ResponseEntity<CustomerDto>(customer, headers, HttpStatus.CREATED);
	}
	@PutMapping("/{customerId}")
	public ResponseEntity<CustomerDto> handlePut(@PathVariable UUID customerId, @RequestBody CustomerDto customerDto){
		CustomerDto dtoSaved = customerService.updateCustomer(customerId, customerDto);
		return new ResponseEntity<CustomerDto>(dtoSaved, HttpStatus.CREATED);
	}
	
	@DeleteMapping("/{customerId}")
	@ResponseStatus(HttpStatus.NO_CONTENT)
	public void deleteCustomerById(@PathVariable UUID customerId) {
		customerService.deleteCustomerById(customerId);
	}

}
