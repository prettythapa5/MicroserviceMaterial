package guru.springframework.msscbrewery.web.service;

import java.util.UUID;

import org.springframework.stereotype.Service;

import guru.springframework.msscbrewery.web.model.Customer;

@Service
public class CustomerServiceImpl implements CustomerService{

	public Customer getCustomerById(UUID customerId) {
		return Customer.builder().customerId(UUID.randomUUID())
				.customerName("Pretty")
				.build();
	}
}
