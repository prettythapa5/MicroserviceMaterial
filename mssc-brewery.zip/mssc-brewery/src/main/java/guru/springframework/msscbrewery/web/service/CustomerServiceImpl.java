package guru.springframework.msscbrewery.web.service;

import java.util.UUID;

import org.springframework.stereotype.Service;

import guru.springframework.msscbrewery.web.model.CustomerDto;
import lombok.extern.log4j.Log4j2;

@Service
@Log4j2
public class CustomerServiceImpl implements CustomerService{

	public CustomerDto getCustomerById(UUID customerId) {
		return CustomerDto.builder().customerId(UUID.randomUUID())
				.customerName("Pretty")
				.build();
	}

	@Override
	public CustomerDto saveNewCustomer(CustomerDto customerDto) {
		return CustomerDto.builder()
				.customerId(UUID.randomUUID())
				.customerName("Avinash")
				.build();
				
	}

	@Override
	public CustomerDto updateCustomer(UUID customerId, CustomerDto customerDto) {
		// TODO Auto-generated method stub
		return CustomerDto.builder()
				.customerId(UUID.randomUUID())
				.customerName("Aisha")
				.build();
	}

	/*
	 * @Override public void deleteCustomerById(UUID customerId) { // TODO
	 * Auto-generated method stub
	 * 
	 * }
	 */
	
	
	  @Override 
	  public void deleteCustomerById(UUID customerId) {
	  System.out.println("Check logs below******************");
	  log.debug("deleted...."); 
	  log.info("Check if customer is deletd or not....");
	  }
	 

}
